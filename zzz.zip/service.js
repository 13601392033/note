var fs =require('fs')
var http =require('http')
var url =require('url')
var path =require('path')

//console.log(app)
http.createServer((req,res)=>{
	var pathname=url.parse(req.url).pathname
	var params=url.parse(req.url,true).query
	var extname=path.extname(pathname)
	if(req.url=='/')pathname='/index.html'
	fs.readFile('./'+pathname,function(err,data){
		if(err){
			return 'no file'
		}
		res.end(data)
	})
}).listen(8765,function(){
	console.log('running on port 8765')
})
